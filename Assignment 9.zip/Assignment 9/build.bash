there is no compile command
run the following command in the terminal
	$ python game.py